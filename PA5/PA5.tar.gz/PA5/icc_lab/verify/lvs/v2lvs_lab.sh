v2lvs -v ./CHIP_pr.v -l NangateOpenCellLibrary_lvs.v -l RF_2P_ADV64_16_lvs.v -l tpz_lvs.v -s NangateOpenCellLibrary_lvs.spi -s RF_2P_ADV64_16_lvs.spi -s tpz_lvs.spi -o CHIP.spi -s1 VDD -s0 VSS
